﻿
using System.ComponentModel.DataAnnotations;

namespace Almacen.Models
{
    public class Categoria
    {

        [Key]
      public int id { get; set; }
        public string nombre { get; set; }

    }
}

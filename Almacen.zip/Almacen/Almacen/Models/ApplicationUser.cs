﻿using Microsoft.AspNetCore.Identity;

namespace Almacen.Models
{
    public class ApplicationUser: IdentityUser
    {
public string Nombre { get; set; }      



    }
}
